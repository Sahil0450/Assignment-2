<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
// including the database connection file
include_once("connection.php");

if(isset($_POST['update']))
{	
	$id = $_POST['id'];
	
	$name = $_POST['name'];
	$qty = $_POST['qty'];
	$price = $_POST['price'];

	// handle image upload
	if(isset($_FILES['image'])) {
		$image_name = $_FILES['image']['name'];
		$image_size = $_FILES['image']['size'];
		$image_tmp = $_FILES['image']['tmp_name'];
		$image_type = $_FILES['image']['type'];

		// get the file extension
		$image_ext = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));

		// generate a unique name for the image
		$image_name_new = uniqid('', true) . '.' . $image_ext;

		// set the upload path
		$upload_path = 'uploads/' . $image_name_new;

		// save the image to the uploads folder
		move_uploaded_file($image_tmp, $upload_path);

		// update the image path in the database
		$result = mysqli_query($mysqli, "UPDATE products SET image='$upload_path' WHERE id=$id");
	}
	
	// checking empty fields
	if(empty($name) || empty($qty) || empty($price)) {
				
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		
		if(empty($qty)) {
			echo "<font color='red'>Quantity field is empty.</font><br/>";
		}
		
		if(empty($price)) {
			echo "<font color='red'>Price field is empty.</font><br/>";
		}		
	} else {	
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE products SET name='$name', qty='$qty', price='$price' WHERE id=$id");
		
		//redirectig to the display page. In our case, it is view.php
		header("Location: view.php");
	}
}
?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM products WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
	$name = $res['name'];
	$qty = $res['qty'];
	$price = $res['price'];
}
?>
<!DOCTYPE html>
<html>
<head>	
	<title>Edit Data</title>
	<style>
		body {
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
		}

		nav {
			background-color: #333;
			color: #fff;
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 10px;
		}

		nav a {
			color: #fff;
			text-decoration: none;
			padding: 5px 10px;
			border-radius: 5

		}
		

		.navbar a:hover {
			background-color: #ddd;
			color: black;
		}	
		
		form {
			margin: 20px auto;
			max-width: 400px;
			padding: 20px;
			background-color: #f2f2f2;
			border-radius: 5px;
		}

		form table {
			width: 100%;
		}

		form td:first-child {
			font-weight: bold;
			padding: 10px;
			width: 30%;
		}

		form input[type="text"] {
			padding: 10px;
			border: none;
			border-radius: 5px;
			margin-bottom: 10px;
			width: 100%;
		}

		form input[type="submit"] {
			background-color: #333;
			color: #fff;
			border: none;
			border-radius: 5px;
			padding: 10px;
			cursor: pointer;
			transition: background-color 0.3s ease;
			width: 100%;
		}

		form input[type="submit"]:hover {
			background-color: #444;
		}
	</style>
</head>

<body>
	<nav>
		<a href="index.php">Home</a>
		<a href="view.php">View Products</a>
		<a href="logout.php">Logout</a>
	</nav>
	
	<form name="form1" method="post" action="edit.php" enctype="multipart/form-data">
		<table >
			<tr> 
				<td>Name</td>
				<td><input type="text" name="name" value="<?php echo $name;?>"></td>
			</tr>
			<tr> 
				<td>Quantity</td>
				<td><input type="text" name="qty" value="<?php echo $qty;?>"></td>
			</tr>
			<tr> 
				<td>Price</td>
				<td><input type="text" name="price" value="<?php echo $price;?>"></td>
			</tr>
			<tr>
                <td>Image</td>
                <td><input type="file" name="image"></td>
            </tr>
			<tr>
				<td><input type="hidden" name="id" value="<?php echo $id ?>"></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>
