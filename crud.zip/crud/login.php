<?php session_start(); ?>
<html>
<head>
	<title>Login</title>
	<style>
		
		body {
			display: flex;
			flex-direction: column;
			align-items: center;
		 }
		
		nav {
			display: flex;
			justify-content: space-between;
			align-items: center;
			background-color: #333;
			color: white;
			padding: 10px;
			width: 100%;
		}
		
		nav a {
			color: white;
			text-decoration: none;
			margin-left: 10px;
		}
		
		nav a:first-child {
			margin-left: 0;
		}
		
		form {
			display: flex;
			flex-direction: column;
			align-items: center;
			margin-top: 50px;
		}
		
		form table {
			border-collapse: collapse;
			margin-top: 10px;
		}
		
		form table td:first-child {
			text-align: right;
			padding-right: 10px;
			font-weight: bold;
		}
		
		form table td input[type="text"],
		form table td input[type="password"],
		form table td input[type="submit"] {
			width: 150px;
			height: 30px;
			border-radius: 5px;
			border: none;
			padding: 5px;
			font-size: 16px;
			margin-left: 10px;
		}
		
		form table td input[type="submit"] {
			background-color: #333;
			color: white;
			cursor: pointer;
		}
		
		form table td input[type="submit"]:hover {
			background-color: #555;
			color: white;	
		}
	</style>
</head>

<body>
	<nav>
		<a href="index.php">Home</a>
	</nav>
	
	<?php
	include("connection.php");

	if(isset($_POST['submit'])) {
		$user = mysqli_real_escape_string($mysqli, $_POST['username']);
		$pass = mysqli_real_escape_string($mysqli, $_POST['password']);

		if($user == "" || $pass == "") {
			echo "Either username or password field is empty.";
			echo "<br/>";
			echo "<a href='login.php'>Go back</a>";
		} else {
			$result = mysqli_query($mysqli, "SELECT * FROM login WHERE username='$user' AND password=md5('$pass')")
						or die("Could not execute the select query.");

			$row = mysqli_fetch_assoc($result);

			if(is_array($row) && !empty($row)) {
				$validuser = $row['username'];
				$_SESSION['valid'] = $validuser;
				$_SESSION['name'] = $row['name'];
				$_SESSION['id'] = $row['id'];
			} else {
				echo "Invalid username or password.";
				echo "<br/>";
				echo "<a href='login.php'>Go back</a>";
			}

			if(isset($_SESSION['valid'])) {
				header('Location: index.php');
			}
		}
	} else {
	?>
		<p><font size="+2">Login</font></p>
		<form name="form1" method="post" action="">
			<table>
				<tr> 
					<td>Username</td>
					<td><input type="text" name="username"></td>
				</tr>
				<tr> 
					<td>Password</td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr> 
				<td>&nbsp;</td>
				<td><input type="submit" name="submit" value="Submit"></td>
			</tr>
		</table>
	</form>
<?php
}
?>
</body>
</html>






