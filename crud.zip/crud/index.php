<?php session_start(); ?>
<html>
<head>
	<title>Homepage</title>
	<style>
		body {
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
		}
		/* Styling for navbar */
		.navbar {
			background-color: #333;
			overflow: hidden;
		}
		.navbar a {
			float: left;
			color: white;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
			font-size: 17px;
		}
		.navbar a:hover {
			background-color: #ddd;
			color: black;
		}
		/* Styling for heading */
		#header {
			text-align: center;
			font-size: 32px;
			margin-top: 50px;
		}
		/* Styling for footer */
		#footer {
			position: fixed;
			bottom: 0;
			left: 0;
			right: 0;
			background-color: #333;
			color: white;
			padding: 10px;
			text-align: center;
			font-size: 14px;
		}
	</style>
</head>

<body>
	<!-- Navbar -->
	<div class="navbar">
		<a href="index.php">Home</a>
		
		<
		<div style="float:right">
			<?php
			if(isset($_SESSION['valid'])) {
				echo "<a href='logout.php'>Logout</a>";
			} else {
				echo "<a href='login.php'>Login</a> | <a href='register.php'>Register</a>";
			}
			?>
		</div>
	</div>
	
	<!-- Heading -->
	<div id="header">
		Welcome to my crud system!
	</div>
	
	<?php
	if(isset($_SESSION['valid'])) {			
		include("connection.php");					
		$result = mysqli_query($mysqli, "SELECT * FROM login");
	?>
		<!-- Logged in user's view -->
		Welcome <?php echo $_SESSION['name'] ?> ! <a href='logout.php'>Logout</a><br/>
		<br/>
		<a href='view.php'>View and Add Products</a>
		<br/><br/>
	<?php	
	} else {
		// Guest user's view
		echo "You must be logged in to view this page.<br/><br/>";
		echo "<a href='login.php'>Login</a> | <a href='register.php'>Register</a>";
	}
	?>
	
	<!-- Footer -->
	<div id="footer">
		<P>Created by student</p>
	</div>
</body>
</html>

