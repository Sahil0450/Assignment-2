<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
    header('Location: login.php');
}
?>

<?php
//including the database connection file
include_once("connection.php");

//fetching data in descending order (lastest entry first)
$result = mysqli_query($mysqli, "SELECT * FROM products WHERE login_id=".$_SESSION['id']." ORDER BY id DESC");
?>

<html>
<head>
    <title>Homepage</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        nav {
            background-color: #333;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 5px;
        }
        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }   
        
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
        }
        
        th, td {
            text-align: left;
            padding: 8px;
        }
        
        tr:nth-child(even){background-color: #f2f2f2}
        
        th {
            background-color:#333 ;
            color: white;
        }
    </style>
</head>

<body>
    <nav>
        <a href="index.php">Home</a>
        <a href="add.html">Add New Data</a>
        <a href="logout.php">Logout</a>
    </nav>
    
    <table>
        <tr>
            <th>Name</th>
            <th>Quantity</th>
            <th>Price (euro)</th>
            <th>Image</th>
            <th>Update</th>
        </tr>
        <?php
        while($res = mysqli_fetch_array($result)) {        
            echo "<tr>";
            echo "<td>".$res['name']."</td>";
            echo "<td>".$res['qty']."</td>";
            echo "<td>".$res['price']."</td>";
            echo "<td><img src='".($res['image'] ?? '')."'></td>";    
            echo "<td><a href=\"edit.php?id=$res[id]\">Edit</a> | <a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";        
        }
        ?>
    </table>    
</body>
</html>
